const { defineConfig } = require("cypress");

module.exports = defineConfig({
  e2e: {
    baseUrl: "http://localhost:3000",
    specPattern: "**/*.spec.js",     // all specs inside tests/ui
    supportFile: false,
    video: false,
    screenshotOnRunFailure: true,
    retries: 1,
  },
});
