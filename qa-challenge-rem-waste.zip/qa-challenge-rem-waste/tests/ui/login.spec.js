describe("REM Waste Login Tests", () => {
  beforeEach(() => {
    cy.visit("http://localhost:3000");
  });

  it("fails login with invalid credentials", () => {
    cy.get("input[placeholder='Username']").type("wronguser");
    cy.get("input[placeholder='Password']").type("wrongpass");
    cy.get("button").contains("Login").click();
    cy.contains("Login failed").should("exist");
  });

  it("succeeds login with valid credentials", () => {
    cy.get("input[placeholder='Username']").type("admin");
    cy.get("input[placeholder='Password']").type("password");
    cy.get("button").contains("Login").click();
    cy.contains("Welcome, admin!").should("exist");
  });
});
