const request = require("supertest");
const app = require("../../backend/server");

let token;
let itemId;

describe("REM Waste API Tests", () => {
  beforeAll(async () => {
    const res = await request(app)
      .post("/login")
      .send({ username: "admin", password: "password" });
    token = res.body.token;
  });

  test("should create a new item", async () => {
    const res = await request(app)
      .post("/items")
      .set("Authorization", `Bearer ${token}`)
      .send({ name: "QA Test Item", description: "Test description" });

    expect(res.statusCode).toBe(201);
    expect(res.body).toHaveProperty("id");
    expect(res.body.name).toBe("QA Test Item");
    itemId = res.body.id;
  });

  test("should retrieve all items", async () => {
    const res = await request(app)
      .get("/items")
      .set("Authorization", `Bearer ${token}`);

    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body.some((item) => item.id === itemId)).toBe(true);
  });

  test("should update the created item", async () => {
    const res = await request(app)
      .put(`/items/${itemId}`)
      .set("Authorization", `Bearer ${token}`)
      .send({ name: "Updated QA Item" });

    expect(res.statusCode).toBe(200);
    expect(res.body.name).toBe("Updated QA Item");
  });

  test("should delete the item", async () => {
    const res = await request(app)
      .delete(`/items/${itemId}`)
      .set("Authorization", `Bearer ${token}`);

    expect(res.statusCode).toBe(200);
    expect(res.body.message).toMatch(/deleted/i);
  });
});
