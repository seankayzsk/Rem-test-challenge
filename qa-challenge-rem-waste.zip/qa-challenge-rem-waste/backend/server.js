const express = require("express");
const cors = require("cors");
const cookieParser = require("cookie-parser");
const { v4: uuidv4 } = require("uuid");

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());
app.use(cookieParser());

// Simple in-memory users database
const users = [{ username: "admin", password: "password" }];
const tokenValue = "valid-token"; // Simple static token for demo auth

// Middleware for token authentication
function auth(req, res, next) {
  const authHeader = req.headers["authorization"];
  if (!authHeader) return res.status(403).json({ message: "No auth header" });

  const token = authHeader.split(" ")[1];
  if (token !== tokenValue) return res.status(403).json({ message: "Invalid token" });

  next();
}

// In-memory items list
let items = [];

// Login route
app.post("/login", (req, res) => {
  const { username, password } = req.body;
  const user = users.find((u) => u.username === username && u.password === password);
  if (!user) return res.status(403).json({ message: "Login failed" });

  // Return token
  res.json({ token: tokenValue, username: user.username });
});

// Get all items (auth required)
app.get("/items", auth, (req, res) => {
  res.json(items);
});

// Create item (auth required)
app.post("/items", auth, (req, res) => {
  const { name, description } = req.body;
  if (!name) return res.status(400).json({ message: "Name required" });

  const newItem = { id: uuidv4(), name, description };
  items.push(newItem);
  res.status(201).json(newItem);
});

// Update item (auth required)
app.put("/items/:id", auth, (req, res) => {
  const id = req.params.id;
  const { name, description } = req.body;

  const itemIndex = items.findIndex((i) => i.id === id);
  if (itemIndex === -1) return res.status(404).json({ message: "Item not found" });

  if (name) items[itemIndex].name = name;
  if (description) items[itemIndex].description = description;

  res.json(items[itemIndex]);
});

// Delete item (auth required)
app.delete("/items/:id", auth, (req, res) => {
  const id = req.params.id;
  const itemIndex = items.findIndex((i) => i.id === id);
  if (itemIndex === -1) return res.status(404).json({ message: "Item not found" });

  items.splice(itemIndex, 1);
  res.json({ message: "Item deleted" });
});

// ✅ Start server ONLY if not in test mode
if (process.env.NODE_ENV !== "test") {
  app.listen(PORT, () => {
    console.log(`Backend API listening at http://localhost:${PORT}`);
  });
}

module.exports = app; // Export for testing
