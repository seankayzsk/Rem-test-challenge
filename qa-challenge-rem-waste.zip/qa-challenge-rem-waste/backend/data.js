let items = [];
let idCounter = 1;

module.exports = {
  getItems: () => items,
  addItem: (item) => {
    const newItem = { id: idCounter++, ...item };
    items.push(newItem);
    return newItem;
  },
  updateItem: (id, updated) => {
    const idx = items.findIndex((i) => i.id === id);
    if (idx !== -1) items[idx] = { ...items[idx], ...updated };
    return items[idx];
  },
  deleteItem: (id) => {
    items = items.filter((i) => i.id !== id);
  },
};
