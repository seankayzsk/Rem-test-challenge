const express = require("express");
const cors = require("cors");
const app = express();
const port = 5000;

app.use(cors());
app.use(express.json());

let posts = [
  { id: 1, title: "Hello", content: "This is first post" },
  { id: 2, title: "Second", content: "Another post" },
];

// GET all posts
app.get("/posts", (req, res) => {
  res.json(posts);
});

// POST new post
app.post("/posts", (req, res) => {
  const { title, content } = req.body;
  if (!title || !content)
    return res.status(400).json({ error: "Title and content required" });
  const newPost = { id: posts.length + 1, title, content };
  posts.push(newPost);
  res.status(201).json(newPost);
});

// PUT update post by id
app.put("/posts/:id", (req, res) => {
  const id = Number(req.params.id);
  const { title, content } = req.body;
  const post = posts.find((p) => p.id === id);
  if (!post) return res.status(404).json({ error: "Post not found" });
  if (title) post.title = title;
  if (content) post.content = content;
  res.json(post);
});

// DELETE post by id
app.delete("/posts/:id", (req, res) => {
  const id = Number(req.params.id);
  posts = posts.filter((p) => p.id !== id);
  res.status(204).send();
});

app.listen(port, () => {
  console.log(`Backend listening at http://localhost:${port}`);
});
