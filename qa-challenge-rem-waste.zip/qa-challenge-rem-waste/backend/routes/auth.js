const express = require("express");
const router = express.Router();

router.post("/login", (req, res) => {
  const { username, password } = req.body;
  if (username === "admin" && password === "password") {
    res.cookie("auth", "true", { httpOnly: true });
    return res.sendStatus(200);
  }
  return res.sendStatus(401);
});

router.post("/logout", (req, res) => {
  res.clearCookie("auth");
  res.sendStatus(200);
});

module.exports = router;
