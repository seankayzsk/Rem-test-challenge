const express = require("express");
const router = express.Router();
const data = require("../data");

const isAuthenticated = (req, res, next) => {
  if (req.cookies.auth === "true") return next();
  return res.sendStatus(401);
};

router.get("/items", isAuthenticated, (req, res) => {
  res.json(data.getItems());
});

router.post("/items", isAuthenticated, (req, res) => {
  const item = data.addItem(req.body);
  res.status(201).json(item);
});

router.put("/items/:id", isAuthenticated, (req, res) => {
  const item = data.updateItem(parseInt(req.params.id), req.body);
  res.json(item);
});

router.delete("/items/:id", isAuthenticated, (req, res) => {
  data.deleteItem(parseInt(req.params.id));
  res.sendStatus(204);
});

module.exports = router;
