import React, { useState, useEffect } from "react";
import axios from "axios";

const API_URL = "http://localhost:5000";

function App() {
  const [token, setToken] = useState(localStorage.getItem("token") || "");
  const [username, setUsername] = useState(localStorage.getItem("username") || "");
  const [loginData, setLoginData] = useState({ username: "", password: "" });
  const [items, setItems] = useState([]);
  const [newItem, setNewItem] = useState({ name: "", description: "" });
  const [editItemId, setEditItemId] = useState(null);
  const [editItemData, setEditItemData] = useState({ name: "", description: "" });
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    if (token) fetchItems();
  }, [token]);

  const fetchItems = async () => {
    try {
      const res = await axios.get(`${API_URL}/items`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setItems(res.data);
    } catch (err) {
      setErrorMessage("Failed to fetch items");
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setErrorMessage("");
    try {
      const res = await axios.post(`${API_URL}/login`, loginData);
      setToken(res.data.token);
      setUsername(res.data.username);
      localStorage.setItem("token", res.data.token);
      localStorage.setItem("username", res.data.username);
      setLoginData({ username: "", password: "" });
    } catch {
      setErrorMessage("Login failed");
    }
  };

  const handleLogout = () => {
    setToken("");
    setUsername("");
    localStorage.removeItem("token");
    localStorage.removeItem("username");
    setItems([]);
  };

  const handleAddItem = async () => {
    setErrorMessage("");
    if (!newItem.name) {
      setErrorMessage("Name is required");
      return;
    }
    try {
      const res = await axios.post(`${API_URL}/items`, newItem, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setItems([...items, res.data]);
      setNewItem({ name: "", description: "" });
    } catch {
      setErrorMessage("Failed to save item");
    }
  };

  const startEditItem = (item) => {
    setEditItemId(item.id);
    setEditItemData({ name: item.name, description: item.description });
  };

  const cancelEdit = () => {
    setEditItemId(null);
    setEditItemData({ name: "", description: "" });
  };

  const saveEditItem = async () => {
    setErrorMessage("");
    try {
      const res = await axios.put(`${API_URL}/items/${editItemId}`, editItemData, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setItems(items.map((item) => (item.id === editItemId ? res.data : item)));
      cancelEdit();
    } catch {
      setErrorMessage("Failed to update item");
    }
  };

  const deleteItem = async (id) => {
    setErrorMessage("");
    try {
      await axios.delete(`${API_URL}/items/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setItems(items.filter((item) => item.id !== id));
    } catch {
      setErrorMessage("Failed to delete item");
    }
  };

  if (!token) {
    return (
      <div style={{ padding: 20 }}>
        <h2>Login</h2>
        {errorMessage && <p style={{ color: "red" }}>{errorMessage}</p>}
        <form onSubmit={handleLogin}>
          <input
            type="text"
            placeholder="Username"
            value={loginData.username}
            onChange={(e) => setLoginData({ ...loginData, username: e.target.value })}
          />
          <br />
          <input
            type="password"
            placeholder="Password"
            value={loginData.password}
            onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
          />
          <br />
          <button type="submit">Login</button>
        </form>
      </div>
    );
  }

  return (
    <div style={{ padding: 20 }}>
      <h2>Welcome, {username}!</h2>
      <button onClick={handleLogout}>Logout</button>

      <h3>Items</h3>
      {errorMessage && <p style={{ color: "red" }}>{errorMessage}</p>}

      <div style={{ marginBottom: 10 }}>
        <input
          placeholder="Name"
          value={newItem.name}
          onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
        />
        <input
          placeholder="Description"
          value={newItem.description}
          onChange={(e) => setNewItem({ ...newItem, description: e.target.value })}
        />
        <button onClick={handleAddItem}>Add Item</button>
      </div>

      <ul>
        {items.map((item) => (
          <li key={item.id} style={{ marginBottom: 8 }}>
            {editItemId === item.id ? (
              <>
                <input
                  value={editItemData.name}
                  onChange={(e) => setEditItemData({ ...editItemData, name: e.target.value })}
                />
                <input
                  value={editItemData.description}
                  onChange={(e) => setEditItemData({ ...editItemData, description: e.target.value })}
                />
                <button onClick={saveEditItem}>Save</button>
                <button onClick={cancelEdit}>Cancel</button>
              </>
            ) : (
              <>
                <strong>{item.name}</strong> - {item.description}{" "}
                <button onClick={() => startEditItem(item)}>Edit</button>{" "}
                <button onClick={() => deleteItem(item.id)}>Delete</button>
              </>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
